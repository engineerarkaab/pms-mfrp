/**
 * 
 */

// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
	
	
	//Adding Custom Method
	  jQuery.validator.addMethod("isSelect", function(value, element) {
		  
		  return value!="select";
		}, "Please select");
	  
	  
	  
	
	
  $("form[name='forgetPasswordForm']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      userName:
      {
    	
    	  required:true
    	  
      },
      hintQuestion:{
    	  required:true,
    	  isSelect:true
	  },
      hintAnswer:"required"
    },
    // Specify validation error messages
    messages: {
      userName: {
    	  required:"Please enter your firstname",
    	  isAplhabetic:"Please enter only Alphabets"
    		  },
      hintQuestion:{
    	  required:"Please select your Question",
    	  isSelect:"Please select your Hint Question"
      },
      hintAnswer:"Please enter your Hint Answer"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
  
  
  
});