
// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
	
	
	//Adding Custom Method
	  jQuery.validator.addMethod("isValidate", function(value, element) {
		  
		  return /^[a-zA-Z0-9@#$%^]+$/.test(value);
		});
	  
	  jQuery.validator.addMethod("isEqual", function(value, element) {
		  
		  //return $("input[name='password']").val()!=value;
		  return $("#password").val()!=value;
		});
	  
	
	
  $("form[name='updatePasswordForm']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      password:
      {
    	
    	  required:true,
    	  minlength:8,
    	  maxlength:15,
    	  isValidate:true
    	  
      },
      cpassword:{
    	  required:true,
    	  isEqual:true
	  }
    },
    // Specify validation error messages
    messages: {
      password: {
    	  required:"Please enter your password",
    	  isValidate:"Please enter Alphanumeric & Special Characters like @,#"
    		  },
      cpassword:{
    	  required:"Please enter your Confirm Password",
    	  isEqual:"Confirm Password & Password Not Equal"
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
  
  
  
});