// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
	
	
	jQuery.validator.addMethod("isSelect", function(value, element) {
		  
		  return value!="select";
		}, "Please select");
	
	jQuery.validator.addMethod("isNumeric", function(value, element) {
		  
		  return /^[0-9]+$/.test(value); 
		}, "Please enter only Numbers");
	
	
  $("form[name='applyPassportForm']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
    	userName: "required",
        country:
        {
        	required:true,
        	isSelect:true
        	
        },
        state:{
        	required:true,
        	isSelect:true
        	
        },
        city:{
        	required:true,
        	isSelect:true
        	
        },
        pin:{
        	required:true,
        	minlength:6,
        	isNumeric: true
        	
        },
        service:{
        	required:true,
        	isSelect:true
        	
        },
        booklet:{
        	required:true,
        	isSelect:true
        	
        }
        	
    },
    // Specify validation error messages
    messages: {
      userName: 
      {
    	  required:"Please enter your username",
    	  isSelect:"Please Select Country"
	  },
      country: {
    	  required:"Please Select Country",
    	  isSelect:"Please Select Country"
	  },
      state:{
    	  required:"Please Select State",
    	  isSelect:"Please Select State"
	  },
      city:{
    	  required:"Please Select City",
    	  isSelect:"Please Select City"
	  },
      pin:
      {
    	  required:"Please enter pin",
    	  isNumeric:"Please Enter only Numbers",
    	  minlength:"Pin must be of 6 digits"
    	  
	  },
	  service:{
    	  required:"Please Select Service",
    	  isSelect:"Please Select Service"
	  },
	  booklet:{
    	  required:"Please Select booklet Dropdown",
    	  isSelect:"Please Select Booket"
	  }
      
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});