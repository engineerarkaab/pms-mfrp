/**
 * 
 */

// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
	
	
	//Adding Custom Method
	  
	  
	  jQuery.validator.addMethod("isAplhabetic", function(value, element) {
		  
		  return /^[a-zA-Z]+$/.test(value); 
		},"Please enter only Alphabets");
	  
	  jQuery.validator.addMethod("isNumeric", function(value, element) {
		  
		  return /^[0-9]+$/.test(value); 
		}, "Please enter only Numbers");
	  
	  jQuery.validator.addMethod("isSelect", function(value, element) {
		  
		  return value!="select";
		}, "Please select");
	  
	  jQuery.validator.addMethod("isValidDate", function(value, element) {
		  //alert(new Date());
		  
		  /*var today = new Date();
		  var dd = today.getDate();
		  var mm = today.getMonth() + 1; //January is 0!
		  var yyyy = today.getFullYear();

		  if(dd < 10) {
		      dd = '0' + dd
		  } 

		  if(mm < 10) {
		      mm = '0' + mm
		  } 

		  today = mm + '/' + dd + '/' + yyyy;*/
		  //var currentDate= new Date();
		  var inputDate= new Date(value);
		  //alert("INput "+input);
		  
		  
		  
		  return inputDate < new Date()
		});
	  
	
	
  $("form[name='userRegistrationForm']").validate({
    // Specify validation rules
	  
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      firstName:
      {
    	
    	  required:true,
    	  isAplhabetic:true
      },
      lastName:
      {
    	  required:true,
    	  isAplhabetic:true
      },
      address:"required",
      dateOfBirth:
      {
    	  required:true,
    	  isValidDate:true
      
      },
      
      contact:{
    	  required:true,
    	  isNumeric:true
    	 
      },
      qualification:"required",
      type:
      {
    	  required:true,
    	  isSelect:true
	  },
      
      hintQuestion:{
    	  required:true,
    	  isSelect:true
	  },
      hintAnswer:"required",
      
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    // Specify validation error messages
    messages: {
      firstName: {
    	  required:"Please enter your firstname",
    	  isAplhabetic:"Please enter only Alphabets"
    		  },
      lastName: {
    	  required:"Please enter your lastname",
    	  isAplhabetic:"Please enter only Alphabets"
    		  },
      address:"Please enter your address",
      dateOfBirth:{
    	 required: "Please enter your date of birth",
    	 isValidDate:"Cannot exceed present date"
      },
      contact:{
    	  required:"Please enter your contact no",
    	  isNumeric:"Please enter only Numbers"
    		  },
      qualification:"Please enter your qualfication",
      type:
      {
    	  required:"Please select your type of Service",
    	  isSelect:"Please select your type of Service"
      },
      hintQuestion:{
    	  required:"Please select your type of Service",
    	  isSelect:"Please select your Hint Question"
      },
      hintAnswer:"Please enter your Hint Answer",
      
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
  
  
  
});