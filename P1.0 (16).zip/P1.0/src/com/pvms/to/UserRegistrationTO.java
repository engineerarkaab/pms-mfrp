package com.pvms.to;

public class UserRegistrationTO {

	private  String firstName,  lastName,
	 dateOfBirth,  address,  contact,  email,
	 qualification,  gender,  type,
	 hintQuestion,hintAnswer,userID,password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserID() {
		return userID;
	}

	public String getHintQuestion() {
		return hintQuestion;
	}

	public void setHintQuestion(String hintQuestion) {
		this.hintQuestion = hintQuestion;
	}

	public UserRegistrationTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	


	public UserRegistrationTO(String firstName, String lastName,
			String dateOfBirth, String address, String contact, String email,
			String qualification, String gender, String type,
			String hintQuestion, String hintAnswer) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.contact = contact;
		this.email = email;
		this.qualification = qualification;
		this.gender = gender;
		this.type = type;
		this.hintQuestion = hintQuestion;
		this.hintAnswer = hintAnswer;
		//System.out.println(this.hintQuestion);
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	/*public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}*/

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getHintAnswer() {
		return hintAnswer;
	}

	public void setHintAnswer(String hintAnswer) {
		this.hintAnswer = hintAnswer;
	}

	public void setUserID(String userID) {
		this.userID=userID;		
	}
	
	
	

}
