package com.pvms.to;

public class UserLoginTO {

	private String userName,userPassword;
	private boolean hasPassport;
	
	
	public boolean isHasPassport() {
		return hasPassport;
	}
	public void setHasPassport(boolean hasPassport) {
		this.hasPassport = hasPassport;
	}
	public UserLoginTO(String userName, String userPassword) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
	}
	public UserLoginTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

}
