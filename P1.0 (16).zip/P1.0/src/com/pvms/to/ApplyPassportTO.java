package com.pvms.to;

public class ApplyPassportTO {

	
	private String userName,country,state,city,pin,service,booklet;
	private String issueDate,expiryDate,passportId;
	private double amount;
	public ApplyPassportTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApplyPassportTO(String userName, String country, String state,
			String city, String pin, String service, String booklet/*,
			String issueDate, String expiryDate, String amount*/) {
		super();
		this.userName = userName;
		this.country = country;
		this.state = state;
		this.city = city;
		this.pin = pin;
		this.service = service;
		this.booklet = booklet;
		/*this.issueDate = issueDate;
		this.expiryDate = expiryDate;
		this.amount = amount;*/
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getBooklet() {
		return booklet;
	}
	public void setBooklet(String booklet) {
		this.booklet = booklet;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getPassportId() {
		return passportId;
	}
	public void setPassportId(String passportId) {
		this.passportId = passportId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

	
	
}
