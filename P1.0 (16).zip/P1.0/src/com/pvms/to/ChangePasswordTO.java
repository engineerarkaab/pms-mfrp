package com.pvms.to;

public class ChangePasswordTO {
	private String userName, hintQuestion,hintAnswer, password;

	public ChangePasswordTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public ChangePasswordTO(String userName, String hintQuestion,
			String hintAnswer, String password) {
		super();
		this.userName = userName;
		this.hintQuestion = hintQuestion;
		this.hintAnswer = hintAnswer;
		this.password = password;
	}


	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getHintQuestion() {
		return hintQuestion;
	}

	public void setHintQuestion(String hintQuestion) {
		this.hintQuestion = hintQuestion;
	}

	public String getHintAnswer() {
		return hintAnswer;
	}

	public void setHintAnswer(String hintAnswer) {
		this.hintAnswer = hintAnswer;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}

	