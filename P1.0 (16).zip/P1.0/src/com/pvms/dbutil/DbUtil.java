package com.pvms.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
	
	public static Connection getConnection()
	{
	Connection conn=null;
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/warss";
		String user="root";
		String password="root";
		Connection con=DriverManager.getConnection(url, user, password);
		conn=con;
		//System.out.println(conn);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	return conn;
}
	
}
