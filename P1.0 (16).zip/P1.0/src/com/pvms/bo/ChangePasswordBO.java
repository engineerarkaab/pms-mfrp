package com.pvms.bo;

import com.pvms.dao.ChangePasswordDao;
import com.pvms.to.ChangePasswordTO;

public class ChangePasswordBO {
	
	public boolean doChangePassword(ChangePasswordTO changePasswordTo){
		return ChangePasswordDao.doChangePassword(changePasswordTo);
	}
}
