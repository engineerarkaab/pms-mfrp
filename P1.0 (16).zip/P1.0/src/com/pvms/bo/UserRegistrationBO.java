package com.pvms.bo;

import com.pvms.dao.UserRegistrationDAO;
import com.pvms.to.UserRegistrationTO;

public class UserRegistrationBO {

	public boolean doUserRegistration(UserRegistrationTO userRegistrationTo) {
		// TODO Auto-generated method stub
		UserRegistrationDAO userRegistrationDao=new UserRegistrationDAO();
		return userRegistrationDao.registerUser(userRegistrationTo);

	}

}
