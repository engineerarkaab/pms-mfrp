package com.pvms.bo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.pvms.dao.PassportRenewalDAO;
import com.pvms.to.PassportRenewalTO;

public class PassportRenewalBO {

	public boolean doRenewPassport(PassportRenewalTO passportRenewalTo) {
		
		PassportRenewalDAO passportRenewalDao=new PassportRenewalDAO();
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal=Calendar.getInstance();
		Date cDate = cal.getTime();/*new Date();*/
		
		String currentDate=sdf.format(cDate);
		
		passportRenewalTo.setIssueDate(currentDate);
		
		cal.add(cal.YEAR, 10);
		Date eDate=cal.getTime();
		
		String expiryDate=sdf.format(eDate);
		double amount=0;
		if(passportRenewalTo.getService().equalsIgnoreCase("1")){
			amount=1500;
		}
		else if(passportRenewalTo.getService().equalsIgnoreCase("2")){
			amount=3000;
		}
		
		passportRenewalTo.setExpiryDate(expiryDate);
		passportRenewalTo.setAmount(amount);
		
		return passportRenewalDao.doRenewalPassport(passportRenewalTo);
	}

}
