package com.pvms.bo;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.pvms.dao.ApplyPassportDAO;
import com.pvms.to.ApplyPassportTO;

public class ApplyPassportBO {
	
	/*
		doApplyPassport- method for applying new passport
	 */
	
	public boolean doApplyPassport(ApplyPassportTO applypassportTo)
	{
		ApplyPassportDAO applyPassportDao=new ApplyPassportDAO();
		
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal=Calendar.getInstance();
		Date cDate = cal.getTime();/*new Date();*/
		
		String currentDate=sdf.format(cDate);
		
		applypassportTo.setIssueDate(currentDate);
		
		cal.add(Calendar.YEAR, 10);
		Date eDate=cal.getTime();
		
		String expiryDate=sdf.format(eDate);
		double amount=0;
		if(applypassportTo.getService().equalsIgnoreCase("1")){
			amount=2500;
		}
		else if(applypassportTo.getService().equalsIgnoreCase("2")){
			amount=5000;
		}
		
		
		applypassportTo.setExpiryDate(expiryDate);
		applypassportTo.setAmount(amount);
		
		
		return applyPassportDao.doApplyPassport(applypassportTo);
	}

	/*public List<String> fetchStateList() throws SQLException {
		
		ApplyPassportDAO applyPassportDAO=new ApplyPassportDAO();
		return applyPassportDAO.fetchStateList();
		
	}*/
	
	/*
		fetchCountryList- method for fetching countries from database
	 */
	
	public List<String> fetchCountryList() throws SQLException {
		
		ApplyPassportDAO applyPassportDAO=new ApplyPassportDAO();
		return applyPassportDAO.fetchCountryList();
		
	}

	/*
	getStateList- method for getting states from database
 */
	
	
	public List<String> getStateList(ApplyPassportTO fetchStateTo) {
		// TODO Auto-generated method stub
		
		ApplyPassportDAO fetchStateDao= new ApplyPassportDAO();
		return fetchStateDao.getStateList(fetchStateTo);
	}

	/*
	getCityList- method for getting cities from database
 */
	
	public List<String> getCityList(ApplyPassportTO fetchCityTo) {
		// TODO Auto-generated method stub
		ApplyPassportDAO fetchCityDao= new ApplyPassportDAO();
		return fetchCityDao.getCityList(fetchCityTo);
		
	}
	
}
