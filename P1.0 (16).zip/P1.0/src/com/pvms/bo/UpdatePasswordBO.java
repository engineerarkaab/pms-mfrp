package com.pvms.bo;

import com.pvms.dao.UpdatePasswordDao;
import com.pvms.to.UpdatePasswordTO;

public class UpdatePasswordBO {

	public boolean doUpdatePassword(UpdatePasswordTO updatePasswordTo) {
		return UpdatePasswordDao.doUpdatePassword(updatePasswordTo);
	}

}
