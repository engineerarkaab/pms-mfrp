package com.pvms.bo;


import com.pvms.dao.UserLoginDAO;
import com.pvms.to.UserLoginTO;

public class UserLoginBO {
	

	public UserLoginBO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean doUserLogin(UserLoginTO userLogin) {
		// TODO Auto-generated method stub
		UserLoginDAO dao=new UserLoginDAO();
		return dao.doUserLogin(userLogin);
		
	}
}
