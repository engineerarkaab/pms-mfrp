package com.pvms.dao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.pvms.dbutil.DbUtil;
import com.pvms.to.UpdatePasswordTO;

public class UpdatePasswordDao {

	public  static boolean doUpdatePassword(UpdatePasswordTO updatePasswordTo) {
		Connection conn=DbUtil.getConnection();
		boolean flag=false;
		try {
			String sql="update register set password = ?" +
			"where userId = ?";
			
			/*System.out.println(updatePasswordTo.getPassword());
			System.out.println(updatePasswordTo.getUserId());*/
			PreparedStatement preparedStatement = conn.prepareStatement(sql);			
			preparedStatement.setString(1,md5encryption(updatePasswordTo.getPassword()));
			preparedStatement.setString(2,updatePasswordTo.getUserId());
			int rowsAffected=preparedStatement.executeUpdate();
			if(rowsAffected>0)
			{
				/*System.out.println("ok");*/
				flag= true;
				conn.close();
				
			}
			else
			{
				/*System.out.println("not ok");*/
			}
	
		} catch (Exception e) {
			//System.out.println(e.getMessage());
		}
		
		
		return flag;
		
	}
	
	private static String md5encryption(String password) throws NoSuchAlgorithmException
	{
		MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());

        byte byteData[] = md.digest();
        StringBuffer hexString = new StringBuffer();
    	for (int i=0;i<byteData.length;i++) {
    		String hex=Integer.toHexString(0xff & byteData[i]);
   	     	if(hex.length()==1) hexString.append('0');
   	     	hexString.append(hex);
    	}
    	//System.out.println(hexString.toString());
    	return hexString.toString();

	}
	
}
