
package com.pvms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pvms.dbutil.DbUtil;
import com.pvms.to.ApplyPassportTO;

public class ApplyPassportDAO {

	public boolean doApplyPassport(ApplyPassportTO applypassportTo) {
		// TODO Auto-generated method stub
		Connection conn=DbUtil.getConnection();
		boolean flag=false;
		try {
			
			applypassportTo.setPassportId(getPassportId(applypassportTo));
			
			String sql="insert into passport(user_id,country_id,state_id,city_id,pin," +
					"tos,booklet_type,issue_date,expiry_date,passport_id,amount) " +
					"values(?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1,applypassportTo.getUserName());
			preparedStatement.setString(2,getCountryId(applypassportTo));
			preparedStatement.setString(3,getStateId(applypassportTo));
			preparedStatement.setString(4,getCityId(applypassportTo));
			preparedStatement.setString(5,applypassportTo.getPin());
			preparedStatement.setString(6,applypassportTo.getService());
			preparedStatement.setString(7,applypassportTo.getBooklet());
			preparedStatement.setString(8,applypassportTo.getIssueDate());
			preparedStatement.setString(9,applypassportTo.getExpiryDate());
			preparedStatement.setString(10,getPassportId(applypassportTo));
			preparedStatement.setDouble(11,applypassportTo.getAmount());
	
			int rowsAffected=preparedStatement.executeUpdate();
			if(rowsAffected>0)
			{
				flag= true;
				conn.close();
				
			}
	
		} catch (Exception e) {
			/*System.out.println(e.getMessage());*/
		}
		
		
		return flag;
	}

	public List<String> fetchStateList(String countryId) throws SQLException {
		Connection conn = DbUtil.getConnection();
		List<String> stateList=new ArrayList<String>();
		try {
			//Statement st = conn.createStatement();
			//System.out.println(conn);
			String sql = "select name from state where country_id=?";
			PreparedStatement preparedStatement=conn.prepareStatement(sql);
			preparedStatement.setInt(1,Integer.parseInt(countryId));
			ResultSet rs = preparedStatement.executeQuery();			
			while(rs.next()) {
				stateList.add(rs.getString(1));
			}
			//System.out.println("Size "+stateList.size());
			//conn.close();
		} catch (Exception ex) {
			/*System.out.println(ex.getMessage());*/
		}
		finally
		{
			
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					/*System.out.println(e);*/
					}
		} 
		
		return stateList;
	}
	
	
	
	public List<String> fetchCountryList() throws SQLException {
		Connection conn = DbUtil.getConnection();
		List<String> countryList=new ArrayList<String>();
		try {
			Statement st = conn.createStatement();
			if (conn != null) {
				String qry = "select name from country";
				ResultSet rs = st.executeQuery(qry);
				while (rs.next()) {
					countryList.add(rs.getString(1));
				}
			}
			conn.close();
		} catch (Exception ex) {
			/*System.out.println(ex.getMessage());*/
		}
		finally
		{
			
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					/*System.out.println(e);*/
					}
		} 
		
		return countryList;
	}
	
	
	
	
	private static String getPassportId(ApplyPassportTO applypassportTo)
	{
		Connection conn=DbUtil.getConnection();
		String passportId[]=null,newPassportId=null;
		try {
			
			if(applypassportTo.getBooklet().equalsIgnoreCase("30"))
			{
				String sql="select ifnull(max(passport_id),'FPS-300000') from passport where passport_id like 'FPS-30%'";
				PreparedStatement preparedStatement1=conn.prepareStatement(sql);
				ResultSet rs=preparedStatement1.executeQuery();  
				if(rs.next())
				{
					//if(rs.getString(1).length()>1){
						passportId=rs.getString(1).split("-");
						long pid=Long.parseLong(passportId[1])+1;
						newPassportId="FPS-"+pid;
					//} 
				}
				else
				{
					newPassportId="FPS-"+300001;
				}
				
			}
			else
			{
				String sql="select ifnull(max(passport_id),'FPS-600000') from passport where passport_id like 'FPS-60%'";
				PreparedStatement preparedStatement1=conn.prepareStatement(sql);
				ResultSet rs=preparedStatement1.executeQuery();  
				if(rs.next())
				{
					//if(rs.getString(1).length()>1){
					 passportId=rs.getString(1).split("-");
					 long pid=Long.parseLong(passportId[1])+1;
					newPassportId="FPS-"+pid;
					//} 
				}
				else
				{
					newPassportId="FPS-"+600001;
				}
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
			/*e.printStackTrace();*/
		}
		return newPassportId;
	}
	
	
	
	private static String getCityId(ApplyPassportTO applypassportTo)
	{
		Connection conn=DbUtil.getConnection();
		String cityId="";
		try {
			
			
				String sql="select id from city where name = ?";
				PreparedStatement preparedStatement1=conn.prepareStatement(sql);
				preparedStatement1.setString(1,applypassportTo.getCity());
				ResultSet rs=preparedStatement1.executeQuery();  
				if(rs.next())
				{
					cityId=rs.getString(1);
					 
					 
				}
				
		} catch (Exception e) {
			// TODO: handle exception
			/*e.printStackTrace();*/
		}
		//System.out.println("state"+cityId);
		return cityId;
	}
	
	
	private static String getStateId(ApplyPassportTO applypassportTo)
	{
		Connection conn=DbUtil.getConnection();
		String stateId="";
		try {
			
			
				String sql="select id from state where name like ?";
				PreparedStatement preparedStatement1=conn.prepareStatement(sql);
				preparedStatement1.setString(1,applypassportTo.getState()+"%");
				ResultSet rs=preparedStatement1.executeQuery();  
				if(rs.next())
				{
					 stateId=rs.getString(1);
					 
					 
				}
				
		} catch (Exception e) {
			// TODO: handle exception
			/*e.printStackTrace();*/
		}
		//System.out.println("state"+stateId);
		return stateId;
	}
	
	
	
	private static String getCountryId(ApplyPassportTO applypassportTo)
	{
		Connection conn=DbUtil.getConnection();
		String countryId="";
		try {
			
			
				String sql="select id from country where name=?";

				PreparedStatement preparedStatement1=conn.prepareStatement(sql);
				preparedStatement1.setString(1, applypassportTo.getCountry());
				ResultSet rs=preparedStatement1.executeQuery();  
				if(rs.next())
				{
					 
					 countryId=rs.getString(1);
					 
				}
				
		} catch (Exception e) {
			// TODO: handle exception
			/*e.printStackTrace();*/
		}
		//System.out.println("country "+countryId);
		return countryId;
	}

	public List<String> getStateList(ApplyPassportTO fetchStateTo) {
		//System.out.println("getStateList called");
		Connection conn=DbUtil.getConnection();
		List<String>stateList= new ArrayList<String>();
		String countryId=getCountryId(fetchStateTo);
		
		try {
			stateList.addAll(fetchStateList(countryId));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			/*e.printStackTrace();*/
		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				/*e.printStackTrace();*/
			}
		}
		return stateList;
		
		
	}

	public List<String> getCityList(ApplyPassportTO fetchCityTo) {
		// TODO Auto-generated method stub
		//return null;
		
		Connection conn=DbUtil.getConnection();
		List<String>cityList= new ArrayList<String>();
		String stateId=getStateId(fetchCityTo);
		
		try {
			cityList.addAll(fetchCityList(stateId));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			/*e.printStackTrace();*/
		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				/*e.printStackTrace();*/
			}
		}
		return cityList;
	}
	
	
	public List<String> fetchCityList(String stateId) throws SQLException {
		Connection conn = DbUtil.getConnection();
		List<String> cityList=new ArrayList<String>();
		try {
			//Statement st = conn.createStatement();
			//System.out.println(conn);
			String sql = "select name from city where state_id=?";
			PreparedStatement preparedStatement=conn.prepareStatement(sql);
			preparedStatement.setInt(1,Integer.parseInt(stateId));
			ResultSet rs = preparedStatement.executeQuery();			
			while(rs.next()) {
				cityList.add(rs.getString(1));
			}
			//System.out.println("Size "+cityList.size());
			//conn.close();
		} catch (Exception ex) {
			/*System.out.println(ex.getMessage());*/
		}
		finally
		{
			
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					/*System.out.println(e);*/
					}
		}
		
		return cityList;
	}
	

}
