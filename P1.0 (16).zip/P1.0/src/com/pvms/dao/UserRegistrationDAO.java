package com.pvms.dao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.pvms.dbutil.DbUtil;
import com.pvms.to.UserRegistrationTO;

public class UserRegistrationDAO {

	public boolean registerUser(UserRegistrationTO userRegistrationTo) {
		// TODO Auto-generated method stub
		Connection conn=DbUtil.getConnection();
		boolean flag=false;
		try
		{
			//PreparedStatement preparedStatement=conn.prepareStatement("insert into user values(?,?,?,?,?,?,?,?,?,?,?)");
			long userId=1000;
			String userIdArray[] = null;
			String fullUserId=null;
			String sql=null;
			if(userRegistrationTo.getType().equalsIgnoreCase("p"))
			{
			 sql="select ifnull(max(userId),'PASS-1000') from register where applyType='p'";
			}
			else
			{
				 sql="select ifnull(max(userId),'VISA-2000') from register where applyType='v'";
			}
			//sql="select max(userId) from register where applyType='p'";
			PreparedStatement preparedStatement1=conn.prepareStatement(sql);
			//preparedStatement1.setString(1, userRegistrationTo.getType());
			//preparedStatement.setString(2, userRegistration.getUserPassword());
			ResultSet rs=preparedStatement1.executeQuery();  
			if(rs.next())  
			{
				//flag=true;
				//split numeric part
				userIdArray=rs.getString(1).split("-");
				userId=Long.parseLong(userIdArray[1]);
				//System.out.println(userIdArray[1]);
				
			}
			userId+=1;
			if(userRegistrationTo.getType().equalsIgnoreCase("v"))
			{
				fullUserId="VISA-"+userId;
			}
			else
			{
				fullUserId="PASS-"+userId;
			}
			Date sysDate=new Date();
			SimpleDateFormat sdf1= new SimpleDateFormat("dd");
			String dd = sdf1.format(sysDate);
			SimpleDateFormat sdf2= new SimpleDateFormat("MMM");
			String mmm = sdf2.format(sysDate);
			
			double x = Math.random() * 1000;
			int y=(int)x;
			if((int)x < 100)
			    y=1000-(int)x;
			String password = dd + mmm + "#" + y;
			
			/*else 
			{
				
			}*/
			
			String sql2="insert into register(fname,lname,dob,address,contact," +
					"email,qualification,gender,applyType,hintQuestion,hintAnswer,userId,password) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement2=conn.prepareStatement(sql2);
			//preparedStatement2.setInt(1, 45);
			preparedStatement2.setString(1,userRegistrationTo.getFirstName());
			preparedStatement2.setString(2,userRegistrationTo.getLastName());
			preparedStatement2.setString(3,userRegistrationTo.getDateOfBirth());
			preparedStatement2.setString(4,userRegistrationTo.getAddress());
			preparedStatement2.setString(5,userRegistrationTo.getContact());
			preparedStatement2.setString(6,userRegistrationTo.getEmail());
			preparedStatement2.setString(7,userRegistrationTo.getQualification());
			preparedStatement2.setString(8, userRegistrationTo.getGender());
			preparedStatement2.setString(9, userRegistrationTo.getType());
			preparedStatement2.setString(10, userRegistrationTo.getHintQuestion());
			preparedStatement2.setString(11, userRegistrationTo.getHintAnswer());
			preparedStatement2.setString(12, fullUserId);
			preparedStatement2.setString(13, md5encryption(password));
			//preparedStatement.setString(2, userRegistration.getUserPassword());
			int rowsAffected=preparedStatement2.executeUpdate();
			if(rowsAffected>0)
			{
				flag=true;
				userRegistrationTo.setUserID(fullUserId);
				userRegistrationTo.setPassword(password);
			}
			
		}
		catch(Exception e){ System.out.println(e);} 
		finally
		{
			
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println(e);}
		} 
		return flag;	
		}
	private String md5encryption(String password) throws NoSuchAlgorithmException
	{
		MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());

        byte byteData[] = md.digest();
        StringBuffer hexString = new StringBuffer();
    	for (int i=0;i<byteData.length;i++) {
    		String hex=Integer.toHexString(0xff & byteData[i]);
   	     	if(hex.length()==1) hexString.append('0');
   	     	hexString.append(hex);
    	}
    	//System.out.println(hexString.toString());
    	return hexString.toString();

	}
}

