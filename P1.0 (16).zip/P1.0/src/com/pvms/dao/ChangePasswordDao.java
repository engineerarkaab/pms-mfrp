package com.pvms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pvms.dbutil.DbUtil;
import com.pvms.to.ChangePasswordTO;

public class ChangePasswordDao {

	public static boolean doChangePassword(ChangePasswordTO changePasswordTo) {
		Connection conn=DbUtil.getConnection();
		boolean flag=true;
		String sql="select hintQuestion,hintAnswer from register where userId like ?";
		try {
			PreparedStatement preparedStatement=conn.prepareStatement(sql);
			//preparedStatement.setString(1, changePasswordTo.getHintQuestion());
			//preparedStatement.setString(2, changePasswordTo.getHintAnswer());
			preparedStatement.setString(1, changePasswordTo.getUserName());
			ResultSet rs=preparedStatement.executeQuery();
			/*System.out.println(changePasswordTo.getUserName());
			System.out.println(changePasswordTo.getHintQuestion());
			System.out.println(changePasswordTo.getHintAnswer());*/
			/*System.out.println("1--"+rs.getString(1));
			System.out.println("2--"+rs.getString(2));*/
			if(rs.next()){
				if(rs.getString(1).equals(changePasswordTo.getHintQuestion()) && rs.getString(2).equals(changePasswordTo.getHintAnswer())){
					/*System.out.println("1");*/
					flag=true;
				}
				else
				{
					/*System.out.println(rs.getString(1));
					System.out.println(rs.getString(2));
					System.out.println("0");*/
					flag=false;
				}
			}
			else{
				flag= false;
			}
		} catch (SQLException e) {
			/*e.printStackTrace();*/
			/*System.out.println("error");*/
			// TODO Auto-generated catch block
				//e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				/*e.printStackTrace();*/
				}
		}
		return flag;
	}

}
