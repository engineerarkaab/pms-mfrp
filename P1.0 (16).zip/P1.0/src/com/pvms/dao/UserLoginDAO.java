package com.pvms.dao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pvms.dbutil.DbUtil;
import com.pvms.to.UserLoginTO;

public class UserLoginDAO {

	public boolean doUserLogin(UserLoginTO userLogin) {
		// TODO Auto-generated method stub
		Connection conn=DbUtil.getConnection();
		boolean flag=false;
		boolean passportStatus=false;
		try
		{
			//PreparedStatement preparedStatement=conn.prepareStatement("insert into user values(?,?,?,?,?,?,?,?,?,?,?)");
			String sql="select userId,password from register where userId=? and password=?";
			PreparedStatement preparedStatement=conn.prepareStatement(sql);
			preparedStatement.setString(1, userLogin.getUserName());
			preparedStatement.setString(2, md5encryption(userLogin.getUserPassword()));
			//preparedStatement.setString(2, userLogin.getUserPassword());
			ResultSet rs=preparedStatement.executeQuery();  
			if(rs.next())  
			{
				flag=true; 
			}
			if(flag){
				String getStatus="select count(user_id) from passport where user_id=?";
				PreparedStatement preparedStatement2=conn.prepareStatement(getStatus);
				preparedStatement2.setString(1, userLogin.getUserName());
				ResultSet rs1=preparedStatement2.executeQuery();
				if(rs1.next())
				{
					if(rs1.getInt(1)!=0)
						userLogin.setHasPassport(true);
					else
						userLogin.setHasPassport(false);
				}
			}
		}
		catch(Exception e){ System.out.println(e);} 
		finally
		{
			
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println(e);}
		} 
		return flag;	
		}
	
	
	private String md5encryption(String password) throws NoSuchAlgorithmException
	{
		MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());

        byte byteData[] = md.digest();
        StringBuffer hexString = new StringBuffer();
    	for (int i=0;i<byteData.length;i++) {
    		String hex=Integer.toHexString(0xff & byteData[i]);
   	     	if(hex.length()==1) hexString.append('0');
   	     	hexString.append(hex);
    	}
    	//System.out.println(hexString.toString());
    	return hexString.toString();

	}

}
