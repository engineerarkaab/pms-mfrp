package com.pvms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import com.pvms.loginController.Dispatcher;
import com.pvms.bo.UserLoginBO;
import com.pvms.to.UserLoginTO;

/**
 * Servlet implementation class UserLogin
 */
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// TODO Auto-generated method stub
		doGetData(request, response);
	}
	
	
	private void doGetData(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		
		String userName=request.getParameter("userName");
		String userPassword=request.getParameter("userPassword");
		//Dispatcher dispatcher=new Dispatcher();
		UserLoginBO userLoginBo=new UserLoginBO();
		UserLoginTO userLoginTo=new UserLoginTO();
		userLoginTo.setUserName(userName);
		userLoginTo.setUserPassword(userPassword);
		if(userLoginBo.doUserLogin(userLoginTo))
		{
			//RequestDispatcher rd= request.getRequestDispatcher("PassportApplication.jsp");
			//rd.forward(request, response);
			HttpSession session=request.getSession();
			session.setAttribute("userName",userName);
			session.setAttribute("hasPassport",userLoginTo.isHasPassport());
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			rd.forward(request, response);
			//response.sendRedirect("UserRegistration.html");
		}
		else{
			/*out.print("<span>Authentication Failure</span>");*/
			//response.sendRedirect("ErrorInformation.html");
			RequestDispatcher rd= request.getRequestDispatcher("index.jsp");
			request.setAttribute("errmsg","Authentication Failure");
			rd.include(request, response);
			//out.print("Invalid Username/Password");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGetData(request, response);
	}

}
