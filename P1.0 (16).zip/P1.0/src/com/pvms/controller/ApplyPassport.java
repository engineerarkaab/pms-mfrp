package com.pvms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pvms.bo.ApplyPassportBO;
import com.pvms.to.ApplyPassportTO;

/**
 * Servlet implementation class ApplyPassport
 */
public class ApplyPassport extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApplyPassport() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGetData(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGetData(request, response);
	}
	

	private void doGetData(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String userName = request.getParameter("userName");
		String country = request.getParameter("country");
		String state = request.getParameter("state");
		String city = request.getParameter("city");
		String pin = request.getParameter("pin");
		String service = request.getParameter("service");
		String booklet = request.getParameter("booklet");
		
		//System.out.println(userName+" "+country+" "+state+" "+city+" "+pin+" "+service+" "+booklet);
		
		/*Date cDate = new Date();
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		String currentDate=sdf.format(cDate);
		
		Calendar cal=Calendar.getInstance();
		cal.add(cal.YEAR, 10);
		Date eDate=cal.getTime();
		
		String expiryDate=sdf.format(eDate);
		int amount=0;
		if(service.equalsIgnoreCase("1")){
			amount=2500;
		}
		else if(service.equalsIgnoreCase("2")){
			amount=5000;
		}*/
		
		ApplyPassportBO applyPassportBo = new ApplyPassportBO();
		// System.out.println(userRegistrationBo);
		ApplyPassportTO applyPassportTo = new ApplyPassportTO();
		
		applyPassportTo.setUserName(userName);
		applyPassportTo.setCountry(country);
		applyPassportTo.setState(state);
		applyPassportTo.setCity(city);
		applyPassportTo.setPin(pin);
		applyPassportTo.setService(service);
		applyPassportTo.setBooklet(booklet);

		// System.out.println(userRegistrationTo);
		if (applyPassportBo.doApplyPassport(applyPassportTo)) {
			/*
			 * HttpSession session=request.getSession();
			 * session.setAttribute("userName",userName);
			 * response.sendRedirect("UserRegistration.html");
			 */
			//System.out.println("success");
			RequestDispatcher rd = request.getRequestDispatcher("SuccessPassport.jsp");
			request.setAttribute("passport",applyPassportTo);
			rd.forward(request, response);
		} 
		else {
			/* out.print("<span>Authentication Failure</span>"); */
			/* response.sendRedirect("ErrorInformation.html"); */
			//System.out.println("failure");
			/* --- RequestDispatcher rd = request.getRequestDispatcher("ErrorInformation.html");
			rd.include(request, response);*/
			RequestDispatcher rd = request.getRequestDispatcher("PassportApplication.jsp");
			request.setAttribute("applyError","Error in Passport Application. Try Again");
			rd.include(request, response);
			

		}
	}


}
