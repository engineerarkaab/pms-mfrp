package com.pvms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pvms.bo.ApplyPassportBO;
import com.pvms.to.ApplyPassportTO;

/**
 * Servlet implementation class FetchState
 */
public class FetchState extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FetchState() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetData(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGetData(request, response);
	}
	
	protected void doGetData(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("Servlet Called");
		PrintWriter out=response.getWriter();
		
		String country=request.getParameter("country");
		//System.out.println(country);
		ApplyPassportBO fetchStateBo= new ApplyPassportBO();
		
		ApplyPassportTO fetchStateTo= new ApplyPassportTO();
		fetchStateTo.setCountry(country);
		
		List<String> stateList=fetchStateBo.getStateList(fetchStateTo);
		out.println("<select name='state' id='state' onchange='showCity()'>");
			for(String state: stateList){			
				out.println("<option value="+state+">"+state+"</option>");
			}
			/*out.println("</select>");
			out.println("<select name='city' id='city'>");
			out.println("<option>Select State</option>");
			out.println("</select>");*/
		
	}

}
