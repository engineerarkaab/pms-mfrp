package com.pvms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pvms.bo.UpdatePasswordBO;
import com.pvms.to.UpdatePasswordTO;

/**
 * Servlet implementation class UpdatePassword
 */
public class UpdatePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetData(request, response);
	}

	protected void doGetData(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String password = request.getParameter("password");
		//
		HttpSession session=request.getSession(false);
		String userName = (String)session.getAttribute("userName");
		//System.out.println("UN" + userName);
		UpdatePasswordBO updatePasswordBo = new UpdatePasswordBO();
		UpdatePasswordTO updatePasswordTo = new UpdatePasswordTO();
		updatePasswordTo.setPassword(password);
		updatePasswordTo.setUserId(userName);
		if(updatePasswordBo.doUpdatePassword(updatePasswordTo)){
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			request.setAttribute("updationSuccess","Password Updated Successfully");
			rd.include(request, response);
		}
		
		else{
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			request.setAttribute("updationSuccess","Error Updating Password. Try Again");
			rd.include(request, response);
			
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetData(request, response);
	}

}
