package com.pvms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import com.pvms.loginController.Dispatcher;
import com.pvms.bo.UserRegistrationBO;
import com.pvms.to.UserRegistrationTO;

/**
 * Servlet implementation class UserRegistration
 */
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub
		doGetData(request, response);
	}

	private void doGetData(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String dateOfBirth = request.getParameter("dateOfBirth");
		String address = request.getParameter("address");
		String contact = request.getParameter("contact");
		String email = request.getParameter("email");
		String qualification = request.getParameter("qualification");
		String gender = request.getParameter("gender");
		//--String password = request.getParameter("password");
		String type = request.getParameter("type");
		String hintAnswer = request.getParameter("hintAnswer");
		String hintQuestion = request.getParameter("hintQuestion");
		//System.out.println("1");
		// Dispatcher dispatcher=new Dispatcher();
		UserRegistrationBO userRegistrationBo = new UserRegistrationBO();
		// System.out.println(userRegistrationBo);
		/*UserRegistrationTO userRegistrationTo = new UserRegistrationTO(
				firstName, lastName, dateOfBirth, address, contact, email,
				qualification, gender, type, hintQuestion, hintAnswer);*/
		
		UserRegistrationTO userRegistrationTo = new UserRegistrationTO();
		userRegistrationTo.setFirstName(firstName);
		userRegistrationTo.setLastName(lastName);
		userRegistrationTo.setDateOfBirth(dateOfBirth);
		userRegistrationTo.setAddress(address);
		userRegistrationTo.setContact(contact);
		userRegistrationTo.setEmail(email);
		userRegistrationTo.setQualification(qualification);
		userRegistrationTo.setGender(gender);
		userRegistrationTo.setType(type);
		userRegistrationTo.setHintQuestion(hintQuestion);
		userRegistrationTo.setHintAnswer(hintAnswer);

		// System.out.println(userRegistrationTo);
		if (userRegistrationBo.doUserRegistration(userRegistrationTo)) {
			/*
			 * HttpSession session=request.getSession();
			 * session.setAttribute("userName",userName);
			 * response.sendRedirect("UserRegistration.html");
			 */
			RequestDispatcher rd = request.getRequestDispatcher("SuccessRegistration.jsp");
			request.setAttribute("user",userRegistrationTo);
			rd.forward(request, response);
		} else {
			/* out.print("<span>Authentication Failure</span>"); */
			/* response.sendRedirect("ErrorInformation.html"); */
			RequestDispatcher rd = request.getRequestDispatcher("UserRegistration.jsp");
			request.setAttribute("registrationError","Error in Registration. Try Again");
			rd.include(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGetData(request, response);
	}

}
