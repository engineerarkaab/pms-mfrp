

package com.pvms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pvms.bo.PassportRenewalBO;
import com.pvms.to.PassportRenewalTO;

/**
 * Servlet implementation class PassportRenewal
 */
public class PassportRenewal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PassportRenewal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("doget");
		doGetData(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("doPost");
		doGetData(request, response);
	}
	
	private void doGetData(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		String userName = request.getParameter("userName");
		String country = request.getParameter("country");
		String state = request.getParameter("state");
		String city = request.getParameter("city");
		String pin = request.getParameter("pin");
		String service = request.getParameter("service");
		String booklet = request.getParameter("booklet");
		String reason = request.getParameter("reason");
		
		//System.out.println(userName+" "+country+" "+state+" "+city+" "+pin+" "+service+" "+booklet);
		
		
		
		PassportRenewalBO passportRenewalBo = new PassportRenewalBO();
		
		PassportRenewalTO passportRenewalTo = new PassportRenewalTO();
		
		passportRenewalTo.setUserName(userName);
		passportRenewalTo.setCountry(country);
		passportRenewalTo.setState(state);
		passportRenewalTo.setCity(city);
		passportRenewalTo.setPin(pin);
		passportRenewalTo.setService(service);
		passportRenewalTo.setBooklet(booklet);
		passportRenewalTo.setReason(reason);
		
		if (passportRenewalBo.doRenewPassport(passportRenewalTo)) {
			
			//System.out.println("success");
			RequestDispatcher rd = request.getRequestDispatcher("SuccessPassportRenewal.jsp");
			request.setAttribute("passport",passportRenewalTo);
			rd.forward(request, response);
		} 
		else {
			
			RequestDispatcher rd = request.getRequestDispatcher("ErrorInformation.html");
			rd.include(request, response);
			

		}
	}

}
