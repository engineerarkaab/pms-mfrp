package com.pvms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pvms.bo.ApplyPassportBO;
import com.pvms.to.ApplyPassportTO;

/**
 * Servlet implementation class FetchCity
 */
public class FetchCity extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FetchCity() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetData(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGetData(request, response);
	}
	
	protected void doGetData(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("City Servlet Called");
		PrintWriter out=response.getWriter();
		
		String state=request.getParameter("state");
		//System.out.println(state);
		ApplyPassportBO fetchCityBo= new ApplyPassportBO();
		
		ApplyPassportTO fetchCityTo= new ApplyPassportTO();
		fetchCityTo.setState(state);
		
		List<String> cityList=fetchCityBo.getCityList(fetchCityTo);
		out.println("<select name='city' id='city'>");
			for(String city: cityList){			
				out.println("<option value="+city+">"+city+"</option>");
			}
			out.println("</select>");		
		
	}

}
