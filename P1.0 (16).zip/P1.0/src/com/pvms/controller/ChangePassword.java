package com.pvms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pvms.bo.ChangePasswordBO;
import com.pvms.to.ChangePasswordTO;

/**
 * Servlet implementation class ChangePassword
 */
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetData(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetData(request, response);
	}
	
	private void doGetData(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		
		
		String userName = request.getParameter("userName");
		String hintQuestion = request.getParameter("hintQuestion");
		String hintAnswer = request.getParameter("hintAnswer");
		//String password = request.getParameter("password");
		//System.out.println(userName);
		
		ChangePasswordBO changePasswordBo = new ChangePasswordBO();
		ChangePasswordTO changePasswordTo = new ChangePasswordTO();
		changePasswordTo.setUserName(userName);
		changePasswordTo.setHintQuestion(hintQuestion);
		changePasswordTo.setHintAnswer(hintAnswer);
		//changePasswordTo.setPassword(password);
		if(changePasswordBo.doChangePassword(changePasswordTo)){
			HttpSession session=request.getSession();
			session.setAttribute("userName",changePasswordTo.getUserName());
			RequestDispatcher rd=request.getRequestDispatcher("UpdatePassword.jsp");
			rd.forward(request, response);
			
		}
		
		else{
			RequestDispatcher rd=request.getRequestDispatcher("ForgetPassword.jsp");
			request.setAttribute("errmsg","Invalid Username/Question/Answer");
			rd.include(request, response);
			
		}
	}

}
